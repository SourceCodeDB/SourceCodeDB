<?php

class MarkusTenghamn_Tasks_Block_Pages_CreateTask extends Mage_Adminhtml_Block_Template
{
	
    /*
    * Where does "_toHtml()" come from?
    * If you trace back the Mage_Adminhtml_Block_Template and all the parents you will see that 
    * "_toHtml()" comes from 
    * 
    * Not that we do not need to use any view (template file). 
    * We can assemble output directly in code => OK to use if no user control is needed on front.
    */

    protected function _toHtml() 
    {
        // fetch write database connection that is used in Mage_Core module
        $write = Mage::getSingleton('core/resource')->getConnection('core_write');
        
        $html = '<div class="content-header">
            <table cellspacing="0" class="grid-header">
                <tr>
                    <td><h3>';
        $html .= $this->__('Create a task');
        $html .= '</h3></td>
                    <td class="a-right">
                        <button onclick="editForm.submit()" class="scalable save" type="button"><span>Submit my form</span></button>
                    </td>
                </tr>
            </table>
        </div>
        <div class="entry-edit">
            <form id="edit_form" name="edit_form" method="post" action="';
        $html .= $this->getUrl('*/*/post');
        $html .= '">
                <input name="form_key" type="hidden" value="';
        $html .= Mage::getSingleton('core/session')->getFormKey();
        $html .= '" />
                <h4 class="icon-head head-edit-form fieldset-legend">';
        $html .= $this->__('Task details');
        $html .= '</h4>
                <fieldset id="my-fieldset">
                    <table cellspacing="0" class="form-list">
                        <tr>
                            <td class="label">';
        $html .= $this->__('Label');
        $html .= '<span class="required">*</span></td>
                            <td class="input-ele"><input class="input-text required-entry" name="taksform[label]" /></td>
                        </tr>
                        <tr>
                            <td class="label">';
        $html .= $this->__('Task creator');
        $html .= '<span class="required">*</span></td>
                            <td class="input-ele"><input class="input-text required-entry" name="taksform[label]" value="will be logged in user" /></td>
                        </tr>
                        <tr>
                            <td class="label">';
        $html .= $this->__('Assigned to');
        $html .= '<span class="required">*</span></td>
                            <td class="input-ele"><input class="input-text required-entry" name="taksform[label]" value="dropdown" /></td>
                        </tr>
                        <tr>
                            <td class="label">';
        $html .= $this->__('Status');
        $html .= '<span class="required">*</span></td>
                            <td class="input-ele"><input class="input-text required-entry" name="taksform[label]" value="dropdown either complete or pending" /></td>
                        </tr>
                        <tr>
                            <td class="label">';
        $html .= $this->__('Date');
        $html .= '<span class="required">*</span></td>
                            <td class="input-ele"><input class="input-text required-entry" name="taksform[label]" value="will be a calendar dropdown"/></td>
                        </tr>
                    </table>
                </fieldset>
            </form>
        </div>
        <script type="text/javascript">
            var editForm = new varienForm("edit_form");
        </script>';
        
        return $html;
    }
}