<?php

class MarkusTenghamn_Tasks_Block_ShowTabsAdminBlock extends Mage_Adminhtml_Block_Widget_Tabs
{   
    public function __construct()
    {
        parent::__construct();
        $this->setId('markustenghamn_tasks_tabs');

        /*
         * By default DestElementId = 'content'... if you trace the function you will see.
         * Meaning, it responds to layout block name?! like "content", "footer", "left"... 
         * Its basicaly telling the layout where to output tabs canvas aka display area
         */
        //$this->setDestElementId('my_custom_edit_form');
        
        $this->setTitle(Mage::helper('taskshelper1')->__('Tasks'));
    }
    
    public function _postAction() 
    {
        // fetch write database connection that is used in Mage_Core module
        $write = Mage::getSingleton('core/resource')->getConnection('core_write');
        //this takes and validates post requests
        $post = $this->getRequest()->getPost();
        try {
            if (empty($post)) {
                Mage::throwException($this->__('Invalid form data.'));
            }
            
            /* here's your form processing */
            
            $message = $this->__('Your form has been submitted successfully.');
            Mage::getSingleton('adminhtml/session')->addSuccess($message);
        } catch (Exception $e) {
            Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
        }
        //Redicrects user back to original page
        $this->_redirect('*/*');
        
        // now $write is an instance of Zend_Db_Adapter_Abstract
        $write->query("insert into tablename values ('aaa','bbb','ccc')");
    }
    
    public function _indexAction() 
    {
        // fetch write database connection that is used in Mage_Core module
        $write = Mage::getSingleton('core/resource')->getConnection('core_write');
    }

    protected function _beforeToHtml()
    {
        $this->addTab('markustenghamn_tasks_tab_1', array(
            'label'     => Mage::helper('taskshelper1')->__('Create Task'),
            'title'     => Mage::helper('taskshelper1')->__('Create Task'),
            'content'   => $this->getLayout()->createBlock("tasksblock1/CreateTask")->toHtml(),
            'active'    => true
        ));

        $this->addTab('markustenghamn_tasks_tab_2', array(
            'label'     => Mage::helper('taskshelper1')->__('Open Tasks'),
            'title'     => Mage::helper('taskshelper1')->__('Open Tasks'),
            'content'   => $this->getLayout()->createBlock("tasksblock1/OpenTasks")->toHtml(),
            'active'    => false
        ));
        
        $this->addTab('markustenghamn_tasks_tab_3', array(
            'label'     => Mage::helper('taskshelper1')->__('Completed Tasks'),
            'title'     => Mage::helper('taskshelper1')->__('Completed Tasks'),
            'content'   => $this->getLayout()->createBlock("tasksblock1/CompletedTasks")->toHtml(),
            'active'    => false
        ));         
        
        return parent::_beforeToHtml();
    }  
}