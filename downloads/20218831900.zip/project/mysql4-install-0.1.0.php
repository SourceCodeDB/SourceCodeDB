<?php
	 
$installer = $this;

$installer->startSetup();

$installer->run("

DROP TABLE IF EXISTS {$this->getTable('tasks')};

CREATE TABLE {$this->getTable('tasks')} (
    `task_id` int(11) unsigned NOT NULL auto_increment,
    `creator_id` int(11) NOT NULL default '',
    `assignedto_id` int(11) NOT NULL default '',
    `name` varchar(255) NOT NULL default '',
    `status` smallint(6) NOT NULL default '0',
    `created_time` datetime NULL,
    `update_time` datetime NULL,
    PRIMARY KEY (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO {$this->getTable('tasks')}(
`task_id` ,
`creator_id` ,
`assignedto_id` ,
`name` ,
`status`
)
VALUES ('1', '1', '1', 'Install Tasks module', '1');

");

$installer->endSetup();