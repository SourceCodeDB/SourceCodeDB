using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Point
{
    class Point
    {
            int X, Y;

            //Constructor that takes 3 parameters
            public Point(int col, int row)
            {
                //calls x and y set methods.
                x = col;
                y = row;

            }


            // get set methods for y
            //value is the variable passed into the constructor, in the constructor it's called "row"
            //NOTE THE DIFFERENCE BETWEEN y AND Y
            public int y
            {
                get
                {
                    //returns Y
                    return Y;
                }
                set
                {
                    //whenever a value is set to y it's validated and then assigned onto the integer Y if it's larger than 0
                    if (value < 0)
                        Y = 0;
                    else
                    {
                        //sets Y to value
                        Y = value;
                    }
                }
            }

            //get set for x
            //NOTE THE DIFFERENCE BETWEEN x AND X
            public int x
            {
                get
                {
                    //Returns X
                    return X;
                }
                set
                {
                    //whenever a value is set to x it's validated and then assigned to the integer Y if it's larger than 0 and less than 80
                    //value is "col" from the constructor
                    if (value > 79)
                        X = 79;
                    else if (value < 0)
                        X = 0;
                    else
                    { //assigns the value to X
                        X = value;
                    }
                }
            }
            public void Print()
            {
                //calls get methods for x and y
                Console.SetCursorPosition(x, y);
                Console.WriteLine('*');

            }
        }
    
}
