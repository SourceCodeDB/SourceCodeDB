using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Point
{
    class Program
    {
        static void Main(string[] args)
        {
            //Creates the point object
            Point p = new Point(50, 20);

            //Calls the print method inside p
            p.Print();

            Console.SetCursorPosition(0, 0);

            //Calls x get part which returns the value of X
            Console.WriteLine(p.x);
            //Calls y get part which return the value of Y
            Console.WriteLine(p.y);


            //Pauses
            Console.ReadLine();
        }
    }
}
