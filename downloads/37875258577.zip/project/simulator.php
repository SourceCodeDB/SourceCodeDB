<?php
ini_set('display_errors',0);
error_reporting(E_ALL);
header("Refresh: 5;");
include('settings.php');
include('db.php');
echo 'In this simulation life has a 1 in 100 chance of being generated. Life can only be generated it if has no neighbors.<br/>
Life will need atleast one neighbor to survive. But if it has more than three neighbors it will die from overcrowding.<br/>
Three or more live cells reporoduce to form a new cell.<br/>';
$n22 = 1;
echo '<div style="width:300px; height:300px; margin-left:auto; margin-right:auto; margin-top:100px;">';
while ($n22 < 101) {
	echo '<div style="width:300px; height:3px;">';
	$n3 = 1;
	$Y = "Y";
	while ($n3 < 101) {
		$Y = "Y";
		$table = $Y.$n22;
		$n2 = $n22;
		$X = "X";
		$n2 = $n2;
		$row = $X.= $n3;
		//echo " ";
		//echo $table;
		//echo " ";
		//echo $row;
		//echo " ";
		$result = mysql_result(mysql_query("SELECT ".$row." FROM ".$table.""),0);
		if ($result == '2') {
			$dieorlive = 0;
			$X = "X";
			$num=0;
			$num=$n3-1;
			$row = $X.$num;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$num=0;
			$num=$n3+1;
			$row = $X.$num;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$Y = "Y";
			$ynum=$n2-1;
			$table = $Y.$ynum;
			$num=0;
			$num=$n3-1;
			$row = $X.$num;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$Y = "Y";
			$ynum=$n2-1;
			$table = $Y.$ynum;
			$row = $X.$n3;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$Y = "Y";
			$ynum=$n2-1;
			$table = $Y.$ynum;
			$num=0;
			$num=$n3+1;
			$row = $X.$num;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$Y = "Y";
			$ynum=$n2+1;
			$table = $Y.$ynum;
			$num=0;
			$num=$n3-1;
			$row = $X.$num;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$Y = "Y";
			$ynum=$n2+1;
			$table = $Y.$ynum;
			$row = $X.$n3;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$Y = "Y";
			$ynum=$n2+1;
			$table = $Y.$ynum;
			$num=0;
			$num=$n3+1;
			$row = $X.$num;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			echo '<div style="width:3px; height:3px; background-color:#000000; float:left;"></div>';
			$table = $Y.=$n2;
			$row = $X.$n3;
			if ($dieorlive > ($neighbormax*2)) {
				mysql_query("UPDATE ".$table." SET ".$row." = '0'");
			}
			else if ($dieorlive < ($neighbormin*2)) {
				mysql_query("UPDATE ".$table." SET ".$row." = '0'");
			}
		}
		else {
			$dieorlive = 0;
			$X = "X";
			$num=0;
			$num=$n3-1;
			$row = $X.$num;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$num=0;
			$num=$n3+1;
			$row = $X.$num;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$Y = "Y";
			$ynum=$n2-1;
			$table = $Y.$ynum;
			$num=0;
			$num=$n3-1;
			$row = $X.$num;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$Y = "Y";
			$ynum=$n2-1;
			$table = $Y.$ynum;
			$row = $X.$n3;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$Y = "Y";
			$ynum=$n2-1;
			$table = $Y.$ynum;
			$num=0;
			$num=$n3+1;
			$row = $X.$num;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$Y = "Y";
			$ynum=$n2+1;
			$table = $Y.$ynum;
			$num=0;
			$num=$n3-1;
			$row = $X.$num;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$Y = "Y";
			$ynum=$n2+1;
			$table = $Y.$ynum;
			$row = $X.$n3;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$Y = "Y";
			$ynum=$n2+1;
			$table = $Y.$ynum;
			$num=0;
			$num=$n3+1;
			$row = $X.$num;
			$dieorlive+= mysql_result(mysql_query("SELECT ".$row." FROM ".$table),0);
			$X = "X";
			$table = $Y.=$n2;
			$row = $X.=$n3;
			echo '<div style="width:3px; height:3px; float:left;"></div>';
			//echo $result;
			if ($dieorlive >= ($neighbortobirth*2)) {
				mysql_query("UPDATE ".$table." SET ".$row." = '2'");
			}
			else if ($dieorlive == 0) {
				$life = rand(1, $life);
				if ($life == 1) {
					mysql_query("UPDATE ".$table." SET ".$row." = '2'");
				}
			}
		}
		
		$n3++;
	}
echo "</div>";
$n22++;
}
echo "</div>";
?>