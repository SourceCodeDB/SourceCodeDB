<?php
$con = mysql_connect($dbhost,$dbuser,$dbpassword);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
mysql_select_db($dbname, $con);

function table_exists($table) {
// open db connection
$result = mysql_query("show tables like '$table'") or die ('error reading database');
if (mysql_num_rows ($result)>0)
return true;
else
return false;
}
?>