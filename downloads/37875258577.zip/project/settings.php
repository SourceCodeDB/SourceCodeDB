<?php
// Mysql details, please use a blank mysql db
$dbhost = "localhost";
$dbuser = "";
$dbpassword = "";
$dbname = "";
// Life will have a 1 in x chance of spawning randomly - default = 100
$life = 100;
// If there are more than x amount of neighbors the cell will die - default = 3
$neighbormax = 3;
// If less than x, If neighbors are too few cell will die
$neighbormin = 1;
// x amount of cells needed to make life - default = 3
$neighbortobirth = 3;
?>