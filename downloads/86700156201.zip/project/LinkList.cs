using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace linkedlist
{
    class LinkList
    {
        LLNode Start;
        LLNode End;
              

        #region Adding
        //Adds a value last in the list
        public  void AddLast(int val)
        {
            if (Start == null)
            {
                Start = new LLNode(val);
                End = Start;
            }
            else
            {
                End.Next = new LLNode(val);
                End = End.Next;
            }
            
    }

        #endregion
        #region Removing
        //Removes the last node
        public void RemoveLast()
        {
            if (Start == End)
            {
                Start = null;
                End = null;
            }
            else
            {
                LLNode Current = Start;
                LLNode tail = null;
                while (Current.Next != null)
                {
                    tail = Current;
                    Current = Current.Next;
                }
                End = tail;
                tail.Next = null;
            }
        }
        //Removes the first node
        public  void RemoveFirst()
        {
            if (Start == End)
                End = null;
            else
            Start = Start.Next; 
        }
        //Removes the node at the given index
        public void RemoveIndex(int index)
        {
            if (index == 0)
                RemoveFirst();

            else  if (Start != End)
            {
                LLNode Current = Start;
                int currPos = 0;
                LLNode tail = null;
                while (Current != null && currPos != index)
                {
                    currPos++;
                    tail = Current;
                    Current = Current.Next;
                }

                if (Current != null)
                {
                    if (Current.Next == null)
                    {
                        End = tail;
                        tail.Next = null;
                    }
                    else
                        tail.Next = Current.Next;
                }
                else
                    Console.WriteLine("There is no node at index: {0}", index);
            }
        }
        #endregion
        #region Searching
        //Returns a node with the 
        public int GetIndexByVal(int val)
        {
            int Index = 0;
            LLNode Current = Start;
            while (Current != null && Current.Value != val)
            {
                Current = Current.Next;
                Index++;
            }
            return Index;
        }
        public bool ValExists(int val)
        {
            LLNode Current = Start;
            while (Current != null && Current.Value != val)
            {
                Current = Current.Next;
            }
            if (Current == null)
                return false;
            else
                return true;

        }
        #endregion

        #region Printing
        //Prints all values in the list
        public  void PrintAll()
        {
           LLNode Current = Start;
           int i = 0;
            while (Current != null)
            {
                Console.Write("\t{0}",i);
                Print(Current);
                Current = Current.Next;
                i++;
            }
        }
        //prints a value
        public void Print(LLNode n)
        {
            Console.WriteLine("\t"+n.Value);
        }
        #endregion

    }
}
