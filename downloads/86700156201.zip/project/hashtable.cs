using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using linkedlist;

namespace Chained_Hashtable
{
    class ChainedHashtable
    {
       LinkList[] Arr;

        public ChainedHashtable(int NoOfElements)
        {
                //I make the Array longer to avoid collisions
            Arr = new LinkList[Convert.ToInt32(NoOfElements*1.3)];
        }

        public void Add(int val)
        {
             AddToPos(val,Hash(val));
        }
        private void AddToPos(int val, int Pos)
        {
            if (Arr[Pos] == null)
                Arr[Pos] = new LinkList();
            Arr[Pos].AddLast(val);
        }
        //Deletes a value if it exists
        public bool Delete(int valToDelete)
        {
            int pos = Hash(valToDelete);
            if (Arr[pos] == null)
            {
                Console.WriteLine("Value not found");
                return false;
            }
            else
            {
                if (Arr[pos].ValExists(valToDelete))
                {
                    Arr[pos].RemoveIndex(Arr[pos].GetIndexByVal(valToDelete));
                    return true;
                }
                else
                    Console.WriteLine("Value not found");
                return false;
            }
        
        }
        //Hash method.
        private int Hash(int val)
        {
            return val % Arr.Length;
        }
        
        public bool Search(int valToFind)
        {
            bool found =false;
            int pos = Hash(valToFind);
            if (Arr[pos] != null)
            {
                found = Arr[pos].ValExists(valToFind);
            }
                return found;
        }
        public void Print()
        {
            Console.WriteLine("KEY\tINDEX\tVALUE");
            Console.WriteLine("---------------------\r\n");
            for (int i = 0; i < Arr.Length; i++)
            {
                Console.Write(i);
                if (Arr[i] != null)
                    Arr[i].PrintAll();
                else
                    Console.WriteLine("\tNULL");
            }
        }
        


    }
}
