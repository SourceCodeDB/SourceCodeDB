using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Chained_Hashtable
{
    class Program
    {
        static void Main(string[] args)
        {
            ChainedHashtable CHT = new ChainedHashtable(100000);
            Random rand = new Random();
            Stopwatch SW = new Stopwatch();
            //adds values between 1 and 200000
            for (int i = 0; i < 100000; i++)
                CHT.Add(rand.Next(200000));

            //Searches for 123123
            SW.Start();
            bool found = CHT.Search(100000);
            SW.Stop();
            if (found)
                Console.WriteLine("Found!");
            else
                Console.WriteLine("Not found");
            Console.WriteLine("Search time: {0}", SW.Elapsed.ToString());
            Console.ReadLine();
        }
    }
}
