<?php
 
// GoPlus Theme Options
// by Markus Tenghamn (http://www.MarkusTenghamn.com)
$themename = "GoPlus";
$shortname = "goplus";
$version = "1.0";

// Create theme options
global $options;
$options = array (
	 
array( "name" => "Plan 1",
 "type" => "section"),
	 
array( "type" => "open"),


 array( "name" => "Plan name",
 "desc" => "",
 "id" => $shortname."_small_name",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Sub heading",
 "desc" => "",
 "id" => $shortname."_small_sub",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Plan price",
 "desc" => "",
 "id" => $shortname."_small_price",
 "type" => "text",
 "std" => ""),
	 
array( "name" => "Small Description",
 "desc" => "Description for the small hosting plan.",
 "id" => $shortname."_small",
 "type" => "textarea",
 "std" => ""),
 
 array( "name" => "Small line 1",
 "desc" => "",
 "id" => $shortname."_small_line_1",
 "type" => "text",
 "std" => ""),
 
  array( "name" => "Small line 2",
 "desc" => "",
 "id" => $shortname."_small_line_2",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Small line 3",
 "desc" => "",
 "id" => $shortname."_small_line_3",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Small line 4",
 "desc" => "",
 "id" => $shortname."_small_line_4",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Buy now URL",
 "desc" => "URL user gets sent to when clicking buy now",
 "id" => $shortname."_small_url",
 "type" => "text",
 "std" => ""),
 
array( "type" => "close"),
 
 array( "name" => "Plan 2",
 "type" => "section"),
	 
array( "type" => "open"),

array( "name" => "Plan name",
 "desc" => "",
 "id" => $shortname."_medium_name",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Sub heading",
 "desc" => "",
 "id" => $shortname."_medium_sub",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Plan price",
 "desc" => "",
 "id" => $shortname."_medium_price",
 "type" => "text",
 "std" => ""),
	 
array( "name" => "Medium Description",
 "desc" => "Description for the medium hosting plan.",
 "id" => $shortname."_medium",
 "type" => "textarea",
 "std" => ""),
 
 array( "name" => "Medium line 1",
 "desc" => "",
 "id" => $shortname."_medium_line_1",
 "type" => "text",
 "std" => ""),
 
  array( "name" => "Medium line 2",
 "desc" => "",
 "id" => $shortname."_medium_line_2",
 "type" => "text",
 "std" => ""),
 
  array( "name" => "Medium line 3",
 "desc" => "",
 "id" => $shortname."_medium_line_3",
 "type" => "text",
 "std" => ""),
 
  array( "name" => "Medium line 4",
 "desc" => "",
 "id" => $shortname."_medium_line_4",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Buy now URL",
 "desc" => "URL user gets sent to when clicking buy now",
 "id" => $shortname."_medium_url",
 "type" => "text",
 "std" => ""),
 
 array( "type" => "close"),
 
 array( "name" => "Plan 3",
 "type" => "section"),
	 
array( "type" => "open"),

array( "name" => "Plan name",
 "desc" => "",
 "id" => $shortname."_large_name",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Sub heading",
 "desc" => "",
 "id" => $shortname."_large_sub",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Plan price",
 "desc" => "",
 "id" => $shortname."_large_price",
 "type" => "text",
 "std" => ""),
 
array( "name" => "Large Description'",
 "desc" => "Description for the large hosting plan.",
 "id" => $shortname."_large",
 "type" => "textarea",
 "std" => ""),
 
 array( "name" => "Large line 1",
 "desc" => "",
 "id" => $shortname."_large_line_1",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Large line 2",
 "desc" => "",
 "id" => $shortname."_large_line_2",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Large line 3",
 "desc" => "",
 "id" => $shortname."_large_line_3",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Large line 4",
 "desc" => "",
 "id" => $shortname."_large_line_4",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Buy now URL",
 "desc" => "URL user gets sent to when clicking buy now",
 "id" => $shortname."_large_url",
 "type" => "text",
 "std" => ""),
	 
array( "type" => "close"),
	 
array( "name" => "Footer",
 "type" => "section"),
	 
array( "type" => "open"),
	 
array( "name" => "Footer Text",
 "desc" => "Paste your text, copyright statements, etc., here.",
 "id" => $shortname."_footer_text",
 "type" => "textarea",
 "std" => ""),
	 
array( "name" => "Analytics/Tracking Code",
 "desc" => "You can paste your Google Analytics or other website tracking code in this box. This will be automatically added to the footer.",
 "id" => $shortname."_analytics_code",
 "type" => "textarea",
 "std" => ""),	
 
array( "type" => "close"),
 
array( "name" => "Main Slider",
 "type" => "section"),
	 
array( "type" => "open"),

array( "name" => "Home page slider heading text",
 "desc" => "This is the heading text for the top of the home page, the area you could call the slider .",
 "id" => $shortname."_slider_heading",
 "std" => "",
 "type" => "textarea"),
 
array( "name" => "Home page slider text",
 "desc" => "This is the text for the top of the home page, the area you could call the slider .",
 "id" => $shortname."_slider",
 "std" => "",
 "type" => "textarea"),
 
 array( "name" => "Info URL",
 "desc" => "URL user gets sent to when clicking More info",
 "id" => $shortname."_info_url",
 "type" => "text",
 "std" => ""),
 
 array( "name" => "Order URL",
 "desc" => "URL user gets sent to when clicking Order",
 "id" => $shortname."_order_url",
 "type" => "text",
 "std" => ""),
 
	array( "type" => "close"),
 
);
 
function goplus_add_admin() {
 
    global $themename, $shortname, $options;
 
    if ( isset ( $_GET['page'] ) && ( $_GET['page'] == basename(__FILE__) ) ) {
 
        if ( isset ($_REQUEST['action']) && ( 'save' == $_REQUEST['action'] ) ){
 
            foreach ( $options as $value ) {
                if ( array_key_exists('id', $value) ) {
                    if ( isset( $_REQUEST[ $value['id'] ] ) ) {
                        update_option( $value['id'], $_REQUEST[ $value['id'] ]  );
                    }
                    else {
                        delete_option( $value['id'] );
                    }
                }
            }
        header("Location: admin.php?page=".basename(__FILE__)."&saved=true");
        }
        else if ( isset ($_REQUEST['action']) && ( 'reset' == $_REQUEST['action'] ) ) {
            foreach ($options as $value) {
               if ( array_key_exists('id', $value) ) {
                    delete_option( $value['id'] );
                }
           }
        header("Location: admin.php?page=".basename(__FILE__)."&reset=true");
        }
    }
 
add_menu_page($themename, $themename, 'administrator', basename(__FILE__), 'goplus_admin');
add_submenu_page(basename(__FILE__), $themename . ' Options', 'Theme Options', 'administrator',  basename(__FILE__),'goplus_admin'); // Default
}
 
function goplus_add_init() {
 
$file_dir=get_bloginfo('template_directory');
wp_enqueue_style("goplusCss", $file_dir."/functions/theme-options.css", false, "1.0", "all");
wp_enqueue_script("goplusScript", $file_dir."/functions/theme-options.js", false, "1.0");
 
}
 
function goplus_admin() {
 
    global $themename, $shortname, $version, $options;
    $i=0;
 
    if ( isset ($_REQUEST['saved']) && ($_REQUEST['saved'] ) )echo '<div id="message" class="updated fade"><p><strong>'.$themename.' settings saved.</strong></p></div>';
    if ( isset ($_REQUEST['reset']) && ($_REQUEST['reset'] ) ) echo '<div id="message" class="updated fade"><p><strong>'.$themename.' settings reset.</strong></p></div>';
 
?>
 
<div class="wrap ">
<div class="options_wrap">
<h2 class="settings-title"><?php echo $themename; ?> Settings</h2>
<form method="post">
 
<?php foreach ($options as $value) {
switch ( $value['type'] ) {
case "section":
?>
    <div class="section_wrap">
    <h3 class="section_title"><?php echo $value['name']; ?></h3>
    <div class="section_body">
 
<?php
break;
case 'text':
?>
 
    <div class="options_input options_text">
        <div class="options_desc"><?php echo $value['desc']; ?></div>
        <span class="labels"><label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label></span>
        <input name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_option( $value['id'] ) != "") { echo stripslashes(get_option( $value['id'])  ); } else { echo $value['std']; } ?>" />
    </div>
 
<?php
break;
case 'textarea':
?>
    <div class="options_input options_textarea">
        <div class="options_desc"><?php echo $value['desc']; ?></div>
        <span class="labels"><label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label></span>
        <textarea name="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" cols="" rows=""><?php if ( get_option( $value['id'] ) != "") { echo stripslashes(get_option( $value['id']) ); } else { echo $value['std']; } ?></textarea>
    </div>
 
<?php
break;
case 'select':
?>
    <div class="options_input options_select">
        <div class="options_desc"><?php echo $value['desc']; ?></div>
        <span class="labels"><label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label></span>
        <select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
        <?php foreach ($value['options'] as $option) { ?>
                <option <?php if (get_option( $value['id'] ) == $option) { echo 'selected="selected"'; } ?>><?php echo $option; ?></option><?php } ?>
        </select>
    </div>
 
<?php
break;
case "radio":
?>
    <div class="options_input options_select">
        <div class="options_desc"><?php echo $value['desc']; ?></div>
        <span class="labels"><label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label></span>
          <?php foreach ($value['options'] as $key=>$option) {
            $radio_setting = get_option($value['id']);
            if($radio_setting != ''){
                if ($key == get_option($value['id']) ) {
                    $checked = 'checked="checked"';
                    } else {
                        $checked = "";
                    }
            }else{
                if($key == $value['std']){
                   $checked = 'checked="checked"';
                }else{
                    $checked = "";
                }
            }?>
            <input type="radio" name="<?php echo $value['id']; ?>" value="<?php echo $key; ?>" <?php echo $checked; ?> /><?php echo $option; ?><br />
            <?php } ?>
    </div>
 
<?php
break;
case "checkbox":
?>
    <div class="options_input options_checkbox">
        <div class="options_desc"><?php echo $value['desc']; ?></div>
        <?php if(get_option($value['id'])){ $checked = 'checked="checked"'; }else{ $checked = "";} ?>
        <input type="checkbox" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" value="true" <?php echo $checked; ?> />
        <label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
    </div>
 
<?php
break;
case "close":
$i++;
?>
<span class="submit"><input name="save<?php echo $i; ?>" type="submit" value="Save Changes" /></span>
</div><!--#section_body-->
</div><!--#section_wrap-->
	 
<?php break;
}
}
?>
 
<input type="hidden" name="action" value="save" />
<span class="submit">
<input name="save" type="submit" value="Save All Changes" />
</span>
</form>
 
<form method="post">
<span class="submit">
<input name="reset" type="submit" value="Reset All Options" />
<input type="hidden" name="action" value="reset" />
</span>
</form>
<br/>
<font size="1">Options page coded by <a href="http://markustenghamn.se">Markus Tenghamn</a> :)<BR/>
Oh and featured images are 480x224, thumbs are 173x106</font>
</div><!--#options-wrap-->
 
</div><!--#wrap-->
<?php
}
add_action('admin_init', 'goplus_add_init');
add_action('admin_menu' , 'goplus_add_admin');
?>
