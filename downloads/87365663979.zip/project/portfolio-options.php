<?php
//By Markus Tenghamn
//Code for portfolio menus and stuff
if ( function_exists( 'add_image_size' ) ) { 
	add_image_size( 'portfolio', 610, 356, false );
}

add_action('init', 'create_portfolio');
	function create_portfolio() {
    	$portfolio_args = array(
        	'label' => __('Portfolio'),
        	'singular_label' => __('Portfolio'),
        	'public' => true,
        	'show_ui' => true,
        	'capability_type' => 'post',
        	'hierarchical' => false,
        	'rewrite' => true,
        	'supports' => array('title', 'editor', 'thumbnail')
        );
	register_post_type('portfolio',$portfolio_args);
}

//For create page

add_action("admin_init", "add_portfolio");
	add_action('save_post', 'update_website_url');
	function add_portfolio(){
		add_meta_box("portfolio_details", "Portfolio Options", "portfolio_options", "portfolio", "normal", "low");
	}
	function portfolio_options(){
		global $post;
		$custom = get_post_custom($post->ID);
		$website_url = $custom["website_url"][0];
?>
	<div id="portfolio-options">
		<label>Website URL:</label><input name="website_url" value="<?php echo $website_url; ?>" />		
	</div><!--end portfolio-options-->   
<?php
	}
	function update_website_url(){
		global $post;
		update_post_meta($post->ID, "website_url", $_POST["website_url"]);
	}
	

//For administration page

add_filter("manage_edit-portfolio_columns", "portfolio_edit_columns");
add_action("manage_posts_custom_column",  "portfolio_columns_display");
 
function portfolio_edit_columns($portfolio_columns){
	$portfolio_columns = array(
		"cb" => "<input type=\"checkbox\" />",
		"title" => "Project Title",
		"description" => "Description",
	);
	return $portfolio_columns;
}
 
function portfolio_columns_display($portfolio_columns){
	switch ($portfolio_columns)
	{
		case "description":
			the_excerpt();
			break;				
	}
}
?>