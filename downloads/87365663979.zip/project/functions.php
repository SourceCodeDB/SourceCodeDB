<?php

$functions_path = TEMPLATEPATH . '/functions/';
//Theme Options
// require_once will include my other files into the functions.php file
require_once ($functions_path . 'theme-options.php');
require_once ($functions_path . 'page-options.php');
require_once ($functions_path . 'portfolio-options.php');


// Here I am registereing some menu areas that can then be utilized in the menu 
// section of the admin
add_action('init', 'register_main_menu');
 
function register_main_menu() {
register_nav_menu('main_menu', __('Main Menu'));
}

add_action('init', 'register_footer_menu');
//MT nimrod
function register_footer_menu() {
register_nav_menu('footer_menu', __('Footer Menu'));
}

add_action('init', 'register_footer_menu2');
//MT nimrod
function register_footer_menu2() {
register_nav_menu('footer_menu2', __('Footer Menu 2'));
}

// Here i register widget areas
function goplus_widgets_init() {
	
	register_sidebar( array(
		'name' => __( 'Main Sidebar', 'goplus' ),
		'id' => 'sidebar',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array(
		'name' => __( 'Footer Area One', 'goplus' ),
		'id' => 'sidebar-1',
		'description' => __( 'An optional widget area for your site footer', 'goplus' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array(
		'name' => __( 'Footer Area Two', 'goplus' ),
		'id' => 'sidebar-2',
		'description' => __( 'An optional widget area for your site footer', 'goplus' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array(
		'name' => __( 'Footer Area Three', 'goplus' ),
		'id' => 'sidebar-3',
		'description' => __( 'An optional widget area for your site footer', 'goplus' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
}
add_action( 'widgets_init', 'goplus_widgets_init' ); // initiate widgets

// Add support for Featured Images
// This will automatically crop images that are too large, very important if you
// want to make sure no one uploads images that are too big and mess up your page
if (function_exists('add_theme_support')) {
    add_theme_support('post-thumbnails', array( 'post', 'page', 'portfolio' ) );
    add_image_size('index-categories', 173, 106, true);
    add_image_size('page-single', 480, 220, true);
}
//Coded by Markus Tenghamn
?>